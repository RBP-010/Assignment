package assignment;

public class Springseason {
    public static void main(String[] args) {
        int d,m;
        for(d=1;d<=31;d++){
            for(m=3;m<=6;m++){
                System.out.println("the spring season is:" +d+" and "+m);
        }}

    }
}
